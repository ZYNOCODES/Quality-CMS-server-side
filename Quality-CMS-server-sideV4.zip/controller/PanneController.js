const sequelize = require('../config/Database.js');
const { Op } = require('sequelize');
const validator = require('validator');
const Panne = require('../model/PanneModel.js');
const Product = require('../model/ProductModel.js');
const Workshop = require('../model/WorkshopModel.js');
const Technician = require('../model/TechnicianModel.js');
const Agent = require('../model/AccessAgentModel.js');
const Family = require('../model/FamilyModel');
const Zone = require('../model/ZoneModel');
const Lot = require('../model/LotModel');
const CustomError = require('../util/CustomError.js');
const PanneType = require('../model/PanneTypeModel.js');
const asyncErrorHandler = require('../util/asyncErrorHandler.js');
const { generateUniqueCode } = require('../util/Codification.js');
const FamilyService = require('../service/FamilyService.js');
const TechnicianService = require('../service/TechnicienService.js');
const ProductService = require('../service/ProductService.js');
const WorkshopService = require('../service/WorkshopService.js');
const ZoneService = require('../service/ZoneService.js');
const PanneService = require('../service/PanneService.js');
const ConsommationService = require('../service/ConsommationService.js');
const ActionCorrectiveService = require('../service/ActionCorrectiveService.js');
const PanneTypeService = require('../service/PanneTypeService.js');
const UserService = require('../service/UsersService.js');
const LotService = require('../service/LotService.js');
const utilMoment = require('../util/Moment.js');
const moment = require('moment');
require('moment-timezone');

// get all pannes by technician
const getAllPannesByTechnician = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the technician exists
    const existingTechnician = await TechnicianService.findTechnicianByCode(code);
    if (!existingTechnician) {
        return next(new CustomError('Technicien non trouvé', 404));
    }

    // Get all pannes by technician
    const pannes = await Panne.findAll({
        where: {
            technician: existingTechnician.id,
            dateReparation: null
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            }
        ],
    })

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get all archive pannes by technician
const getAllArchivePannesByTechnician = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the technician exists
    const existingTechnician = await TechnicianService.findTechnicianByCode(code);
    if (!existingTechnician) {
        return next(new CustomError('Technicien non trouvé', 404));
    }

    // Get all pannes by technician
    const pannes = await Panne.findAll({
        where: {
            technician: existingTechnician.id,
            dateReparation: { [Op.ne]: null }
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            }
        ],
    })

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get all pannes
const getAllPannes = asyncErrorHandler(async (req, res, next) => {
    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            technician: null,
            dateReparation: null
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            }
        ]
    })

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get specific panne
const getSpecificPanne = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if panne exists
    const existingPanne = await Panne.findOne({
        where:{
            code
        },
        include: [
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['code', 'fullname']
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            },
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name']
            },
            {
                model: Product,
                as: 'productAssociation',
                attributes: ['code', 'marque', 'model']
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    })
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }

    // Respond with the panne
    res.status(200).json(existingPanne);
});
// get all pannes by Agent
const getAllPannesByAgent = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(code);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    // Get all pannes by Agent
    const pannes = await Panne.findAll({
        where: {
            agent: existingAgent.id,
            technician: null,
            dateReparation: null
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    })

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get all taken pannes 
const getAllTakenPannes = asyncErrorHandler(async (req, res, next) => {
    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            technician: { [Op.ne]: null },
            dateReparation: null
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get all taken pannes by Agent
const getAllTakenPannesByAgent = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(code);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            agent: existingAgent.id,
            technician: { [Op.ne]: null },
            dateReparation: null
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// get all clotured pannes
const getAllCloturedPannes = asyncErrorHandler(async (req, res, next) => {
    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            technician: { [Op.ne]: null },
            dateReparation: { [Op.ne]: null },
            livraison: true
        },
        include: [
            {
                model: Product,
                as: 'productAssociation',
                attributes: ['marque', 'model', 'lot', 'family', 'zone'],
                include:[
                    {
                        model: Family,
                        as: 'familyAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Zone,
                        as: 'zoneAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Lot,
                        as: 'lotAssociation',
                        attributes: ['name']
                    }
                ]
            },
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['fullname'],
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            },
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }
    // Fetch corrective actions and consumed pieces for each panne
    const pannesWithDetails = await Promise.all(pannes.map(async (panne) => {
        const correctiveActions = await ActionCorrectiveService.findAllActionCorrectiveByPanne(panne.id); 
        const correctiveActionNames = correctiveActions.map(ca => ca.actionAssociation.name);

        const consommations = await ConsommationService.findAllConsommationByPanne(panne.id);
        const consommationNames = consommations.map(c => c.pieceAssociation.name);
        return {
            ...panne.toJSON(),
            correctiveActionNames,
            consommationNames
        };
    }));

    // Respond with the pannes and their associated details
    res.status(200).json(pannesWithDetails);
});
// get all non delivred pannes by Agent
const getAllNoneDelivredPannesByAgent = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(code);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            agent: existingAgent.id,
            technician: { [Op.ne]: null },
            dateReparation: { [Op.ne]: null },
            livraison: false
        },
        include: [
            {
                model: Product,
                as: 'productAssociation',
                attributes: ['marque', 'model', 'lot', 'family', 'zone'],
                include:[
                    {
                        model: Family,
                        as: 'familyAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Zone,
                        as: 'zoneAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Lot,
                        as: 'lotAssociation',
                        attributes: ['name']
                    }
                ]
            },
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['fullname'],
            },
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Fetch corrective actions and consumed pieces for each panne
    const pannesWithDetails = await Promise.all(pannes.map(async (panne) => {
        const correctiveActions = await ActionCorrectiveService.findAllActionCorrectiveByPanne(panne.id); 
        const correctiveActionNames = correctiveActions.map(ca => ca.actionAssociation.name);

        const consommations = await ConsommationService.findAllConsommationByPanne(panne.id);
        const consommationNames = consommations.map(c => c.pieceAssociation.name);
        return {
            ...panne.toJSON(),
            correctiveActionNames,
            consommationNames
        };
    }));

    // Respond with the pannes and their associated details
    res.status(200).json(pannesWithDetails);
});
// get all non delivred pannes by zone
const getAllNoneDelivredPannes = asyncErrorHandler(async (req, res, next) => {
    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            technician: { [Op.ne]: null },
            dateReparation: { [Op.ne]: null },
            livraison: false
        },
        include: [
            {
                model: Product,
                as: 'productAssociation',
                attributes: ['marque', 'model', 'lot', 'family', 'zone'],
                include:[
                    {
                        model: Family,
                        as: 'familyAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Zone,
                        as: 'zoneAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Lot,
                        as: 'lotAssociation',
                        attributes: ['name']
                    }
                ]
            },
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['fullname'],
            },
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Fetch corrective actions and consumed pieces for each panne
    const pannesWithDetails = await Promise.all(pannes.map(async (panne) => {
        const correctiveActions = await ActionCorrectiveService.findAllActionCorrectiveByPanne(panne.id); 
        const correctiveActionNames = correctiveActions.map(ca => ca.actionAssociation.name);

        const consommations = await ConsommationService.findAllConsommationByPanne(panne.id);
        const consommationNames = consommations.map(c => c.pieceAssociation.name);
        return {
            ...panne.toJSON(),
            correctiveActionNames,
            consommationNames
        };
    }));

    // Respond with the pannes and their associated details
    res.status(200).json(pannesWithDetails);
});
// get all clotured pannes by Agent
const getAllCloturedPannesByAgent = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(code);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    // Get all pannes by zone
    const pannes = await Panne.findAll({
        where: {
            agent: existingAgent.id,
            technician: { [Op.ne]: null },
            dateReparation: { [Op.ne]: null },
            livraison: true
        },
        include: [
            {
                model: Product,
                as: 'productAssociation',
                attributes: ['marque', 'model', 'lot', 'family', 'zone'],
                include:[
                    {
                        model: Family,
                        as: 'familyAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Zone,
                        as: 'zoneAssociation',
                        attributes: ['name']
                    },
                    {
                        model: Lot,
                        as: 'lotAssociation',
                        attributes: ['name']
                    }
                ]
            },
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['fullname'],
            },
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            }
        ]
    });

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Fetch corrective actions and consumed pieces for each panne
    const pannesWithDetails = await Promise.all(pannes.map(async (panne) => {
        const correctiveActions = await ActionCorrectiveService.findAllActionCorrectiveByPanne(panne.id); 
        const correctiveActionNames = correctiveActions.map(ca => ca.actionAssociation.name);

        const consommations = await ConsommationService.findAllConsommationByPanne(panne.id);
        const consommationNames = consommations.map(c => c.pieceAssociation.name);
        return {
            ...panne.toJSON(),
            correctiveActionNames,
            consommationNames
        };
    }));

    // Respond with the pannes and their associated details
    res.status(200).json(pannesWithDetails);
});
// get pannes by product
const GetPannesByProduct = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;

    // Validate required fields
    if ([code].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the product exists
    const existingProduct = await ProductService.findProductByCode(code);
    if (!existingProduct) {
        return next(new CustomError('Produit non trouvé', 404));
    }

    // Get all pannes by product
    const pannes = await Panne.findAll({
        where: {
            product: existingProduct.id
        },
        include: [
            {
                model: Workshop,
                as: 'workshopAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: Technician,
                as: 'technicianAssociation',
                attributes: ['code', 'fullname'],
            },
            {
                model: PanneType,
                as: 'typepanneAssociation',
                attributes: ['code', 'name'],
            },
            {
                model: Agent,
                as: 'agentAssociation',
                attributes: ['code', 'fullname'],
            }
        ]
    })

    //check if the pannes were found
    if (!pannes || pannes.length <= 0) {
        return next(new CustomError('Aucune panne trouvée', 404));
    }

    // Respond with the pannes
    res.status(200).json(pannes);
});
// first panne step
const firstPanneStep = asyncErrorHandler(async (req, res, next) => {
    const { agent } = req.params;
    const { marque, model, sn, lot, family, workshop, fournisseur, panne, ligne } = req.body;
    // Validate required fields
    if ([ agent, marque, model, sn, lot, family, workshop, fournisseur, panne, ligne].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    // Start a transaction
    const transaction = await sequelize.transaction();
    try {
        // Validate existence of related entities
        const [existingFamily , existingWorkshop , existingPanneType, existingAgent, existingLot] = await Promise.all([
            FamilyService.findFamilyByCode(family),
            WorkshopService.findWorkshopByCode(workshop),
            PanneTypeService.findPanneTypeByCode(panne),
            UserService.findAgentByCode(agent),
            LotService.findLotByName(lot),
        ]);
        if (!existingAgent) return next(new CustomError('Agent non trouvé', 404));
        if (!existingFamily) return next(new CustomError('Famille non trouvée', 404));
        if (!existingWorkshop) return next(new CustomError('Atelier non trouvé', 404));
        if (!existingPanneType) return next(new CustomError('Type de panne non trouvé', 404));
        if (!existingLot) return next(new CustomError('Lot non trouvé', 404));

        // Check if the Product already exists
        let product = await ProductService.findProductByModelAndLot(model, existingLot.id);

        if (!product) {
            // Generate a unique code for the product
            const code = await generateUniqueCode("P", 6, Product);
            if (!code) return next(new CustomError('Un problème est survenu, veuillez réessayer.', 400));

            // Create a new Product
            product = await Product.create({
                code,
                marque,
                model,
                lot: existingLot.id,
                family: existingFamily.id,
                zone: existingWorkshop.zone
            }, { transaction });

            if (!product) return next(new CustomError('Un problème est survenu lors de la création d\'un produit, veuillez réessayer.', 400));
        }

        // Get the current date and time
        const dateDeclaration = utilMoment.getCurrentDateTime();

        // Generate a unique code for the panne
        const code = await generateUniqueCode("PN", 6, Panne);
        if (!code) return next(new CustomError('Un problème est survenu, veuillez réessayer.', 400));

        // Create a new Panne
        const newPanne = await Panne.create({
            code,
            dateDeclaration,
            fournisseur,
            sn,
            agent: existingAgent.id,
            panne: existingPanneType.id,
            ligne,
            product: product.id,
            workshop: existingWorkshop.id
        }, { transaction });

        if (!newPanne) return next(new CustomError('Un problème est survenu lors de la création d\'une panne, veuillez réessayer.', 400));

        // Commit the transaction
        await transaction.commit();

        // Send the response message
        res.status(200).json({ message: 'Panne créée avec succès' });
    } catch (error) {
        // Rollback the transaction in case of error
        await transaction.rollback();
        console.log(error)
        return next('Error: Internal Server', 500);
    }
});
// second panne step
const secondPanneStep = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;
    const { codeT, agent } = req.body;
    // Validate required fields
    if ([code, codeT, agent].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(agent);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    //check if technician exists
    const existingTechnician = await TechnicianService.findTechnicianByCode(codeT);
    if(!existingTechnician){
        return next(new CustomError('Technician non trouvée', 404));
    }

    //check if panne exists
    const existingPanne = await PanneService.findPanneByCode(code);
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }
    
    //check if its the same agent who create this panne
    if(existingAgent.id != existingPanne.agent){
        return next(new CustomError('Vous n\'avez pas l\'autorisation pour effectuer cette action', 400));
    }

    //check if technician have current panne in progress
    const existingPanneInProgress = await PanneService.findPanneInProgressByTechnician(existingTechnician.id);
    if(existingPanneInProgress){
        return next(new CustomError('Vous avez déjà eu une panne en cours vous devez la terminer', 400));
    }

    //check if the panne is already assigned to a technician
    if(existingPanne.technician){
        return next(new CustomError('Cette panne est déjà assignée à un technicien', 400));
    }

    // Get the current date and time
    const tempInitial = utilMoment.getCurrentDateTime();
    
    //update the panne 
    existingPanne.technician = existingTechnician.id;
    existingPanne.tempInitial = tempInitial;

    //save the updated panne
    const updatedPanne = await existingPanne.save();

    //check if the panne was updated successfully
    if (!updatedPanne) {
        return next(new CustomError('Un problème est survenu lors de la mise à jour du panne, veuillez réessayer.', 400));
    }

    // Respond with success message
    res.status(200).json({ message: 'Panne mis à jour avec succès' });
});
// third panne step
const thirdPanneStep = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;
    const { source, etat, agent } = req.body;
    // Validate required fields
    if ([code, agent].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }
    // Validate required fields
    if ([source, etat].every(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Un des champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(agent);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    //check if panne exists
    const existingPanne = await PanneService.findPanneByCode(code);
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }

    //check if its the same agent who create this panne
    if(existingAgent.id != existingPanne.agent){
        return next(new CustomError('Vous n\'avez pas l\'autorisation pour effectuer cette action', 400));
    }

    //check if the panne is submitted to second scan
    if(!existingPanne.technician && !existingPanne.tempInitial){
        return next(new CustomError('La panne n\'a pas encore été soumise au deuxième scan', 400));
    }

    //update the panne 
    if (source) existingPanne.source = source;
    if (etat) existingPanne.etat = etat;
    
    //save the updated panne
    const updatedPanne = await existingPanne.save();

    //check if the panne was updated successfully
    if (!updatedPanne) {
        return next(new CustomError('Un problème est survenu lors de la mise à jour du panne, veuillez réessayer.', 400));
    }

    // Respond with success message
    res.status(200).json({ message: 'Panne mis à jour avec succès' });
});
// fourth panne step
const fourthPanneStep = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;
    const { agent } = req.body;
    // Validate required fields
    if ([code, agent].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tout les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(agent);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    //check if panne exists
    const existingPanne = await PanneService.findPanneByCode(code);
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }

    //check if its the same agent who create this panne
    if(existingAgent.id != existingPanne.agent){
        return next(new CustomError('Vous n\'avez pas l\'autorisation pour effectuer cette action', 400));
    }

    //check if the panne is submitted to second scan
    if(!existingPanne.technician && !existingPanne.tempInitial){
        return next(new CustomError('La panne n\'a pas encore été soumise au deuxième scan', 400));
    }

    //check if the panne is already have action corrective and consommation
    const existingConsommation = await ConsommationService.findConsommationByPanne(existingPanne.id);
    const existingActionCorrective = await ActionCorrectiveService.findActionCorrectiveByPanne(existingPanne.id);
    if(!existingConsommation || !existingActionCorrective){
        return next(new CustomError('Vous ne pouvez pas clôturer cette panne car elle n\'a pas de PDRConsome ou d\'action corrective.', 400));
    }

    //check if the panne is already closed
    if(existingPanne.dateReparation){
        return next(new CustomError('Cette panne est déjà clôturée', 400));
    }
    
    // Get the current date and time
    const dateReparation = utilMoment.getCurrentDateTime();
    //check if dateReparation is greater than existingPanne.tempInitial
    if(moment.utc(dateReparation).isBefore(moment.utc(existingPanne.tempInitial))){
        return next(new CustomError('La date de réparation doit être supérieure à la date d\'intervention', 400));
    }
    // Calculate the difference in milliseconds
    let dureeInMilliseconds = moment.utc(dateReparation).diff(moment.utc(existingPanne.tempInitial));

    //update the panne 
    existingPanne.dateReparation = dateReparation;
    existingPanne.tempFinal = dateReparation;
    existingPanne.dureeDintervention = dureeInMilliseconds;

    //save the updated panne
    const updatedPanne = await existingPanne.save();

    //check if the panne was updated successfully
    if (!updatedPanne) {
        return next(new CustomError('Un problème est survenu lors de la mise à jour du panne, veuillez réessayer.', 400));
    }

    // Respond with success message
    res.status(200).json({ message: 'La panne a ete clôturé avec succès' });
});
// make panne delivred
const MakePanneDelivred = asyncErrorHandler(async (req, res, next) => {
    const { code } = req.params;
    const { agent } = req.body;
    // Validate required fields
    if ([code, agent].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Tous les champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(agent);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    //check if panne exists
    const existingPanne = await PanneService.findPanneByCode(code);
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }

    //check if its the same agent who create this panne
    if(existingAgent.id != existingPanne.agent){
        return next(new CustomError('Vous n\'avez pas l\'autorisation pour effectuer cette action', 400));
    }

    //check if this panne is clotured
    if(!existingPanne.dateReparation || !existingPanne.dureeDintervention ){
        return next(new CustomError('La panne n\'est pas encore cloturé par l\'agent', 400)); 
    }

    // Get the current date and time
    const date = utilMoment.getCurrentDateTime();
    
    //update the panne 
    existingPanne.livraison = true;
    existingPanne.DateLivraison = date;

    //save the updated panne
    const updatedPanne = await existingPanne.save();

    //check if the panne was updated successfully
    if (!updatedPanne) {
        return next(new CustomError('Un problème est survenu lors de la mise à jour du panne, veuillez réessayer.', 400));
    }

    // Respond with success message
    res.status(200).json({ message: 'Panne mis à jour avec succès' });
});
// delete panne
const DeletePanne = asyncErrorHandler(async (req, res, next) => {
    const { code, agent } = req.params;
    // Validate required fields
    if ([code, agent].some(field => !field || validator.isEmpty(field.toString()))) {
        return next(new CustomError('Un des champs doivent être remplis', 400));
    }

    //check if the Agent exists
    const existingAgent = await UserService.findAgentByCode(agent);
    if (!existingAgent) {
        return next(new CustomError('Agent non trouvée', 404));
    }

    //check if panne exists
    const existingPanne = await PanneService.findPanneByCode(code);
    if(!existingPanne){
        return next(new CustomError('Panne non trouvée', 404));
    }

    //check if its the same agent who create this panne
    if(existingAgent.id != existingPanne.agent){
        return next(new CustomError('Vous n\'avez pas l\'autorisation pour effectuer cette action', 400));
    }

    //check if there is consommation and actioncorrective related to this panne
    const existingConsommation = await ConsommationService.findConsommationByPanne(existingPanne.id);
    const existingActionCorrective = await ActionCorrectiveService.findActionCorrectiveByPanne(existingPanne.id);
    if(existingConsommation || existingActionCorrective){
        return next(new CustomError('Vous ne pouvez pas supprimer cette panne car elle est liée à un PDRConsome ou une action corrective existante.', 400));
    }
    //deletec Panne
    const deletedPanne = await existingPanne.destroy();
    //check if Panne is deleted
    if (!deletedPanne) {
        return next(new CustomError('Un problème est survenu lors de la suppression d\'une panne, veuillez réessayer.', 400));
    }
    res.status(200).json({ message: 'Panne supprimée avec succès' });
});

module.exports = {
    getAllPannesByTechnician,
    getAllArchivePannesByTechnician,
    getSpecificPanne,
    getAllPannes,
    getAllPannesByAgent,
    getAllTakenPannes,
    getAllTakenPannesByAgent,
    getAllCloturedPannes,
    getAllNoneDelivredPannes,
    getAllNoneDelivredPannesByAgent,
    getAllCloturedPannesByAgent,
    firstPanneStep,
    secondPanneStep,
    thirdPanneStep,
    fourthPanneStep,
    MakePanneDelivred,
    DeletePanne,
    GetPannesByProduct
}